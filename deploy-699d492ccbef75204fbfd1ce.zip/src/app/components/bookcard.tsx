import { Link } from 'react-router';
import { ShoppingCart, Star, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { Book } from '../data/books';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter } from './ui/card';

interface BookCardProps {
  book: Book;
}

export function BookCard({ book }: BookCardProps) {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(book.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(book);
    toast.success(`${book.title} added to cart!`);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    if (inWishlist) {
      removeFromWishlist(book.id);
      toast.success(`${book.title} removed from wishlist`);
    } else {
      addToWishlist(book);
      toast.success(`${book.title} added to wishlist!`);
    }
  };

  return (
    <Link to={`/book/${book.id}`}>
      <Card className="h-full hover:shadow-lg transition-shadow overflow-hidden relative group">
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 z-10 bg-white/90 hover:bg-white shadow-sm"
          onClick={handleToggleWishlist}
        >
          <Heart className={`size-4 ${inWishlist ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
        </Button>
        <div className="aspect-[2/3] overflow-hidden bg-gray-100">
          <img
            src={book.cover}
            alt={book.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <CardContent className="p-3 md:p-4">
          <div className="flex items-center gap-1 mb-2">
            <Star className="size-3 md:size-4 fill-yellow-400 text-yellow-400" />
            <span className="text-xs md:text-sm">{book.rating}</span>
            <span className="text-xs md:text-sm text-gray-500">({book.reviews})</span>
          </div>
          <h3 className="font-semibold text-sm md:text-base mb-1 line-clamp-1">{book.title}</h3>
          <p className="text-xs md:text-sm text-gray-600 mb-2 line-clamp-1">{book.author}</p>
          <p className="text-xs text-gray-500 mb-2 md:mb-3">{book.genre}</p>
          <p className="text-base md:text-lg font-bold text-primary">₹{book.price}</p>
        </CardContent>
        <CardFooter className="p-3 md:p-4 pt-0">
          <Button 
            className="w-full text-xs md:text-sm h-8 md:h-10" 
            onClick={handleAddToCart}
          >
            <ShoppingCart className="size-3 md:size-4 mr-1 md:mr-2" />
            Add to Cart
          </Button>
        </CardFooter>
      </Card>
    </Link>
  );
}