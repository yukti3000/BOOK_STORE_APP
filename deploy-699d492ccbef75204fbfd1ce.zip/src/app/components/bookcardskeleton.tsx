import { Skeleton } from './ui/skeleton';
import { Card, CardContent, CardFooter } from './ui/card';

export function BookCardSkeleton() {
  return (
    <Card className="h-full overflow-hidden">
      <Skeleton className="aspect-[2/3] w-full" />
      <CardContent className="p-3 md:p-4">
        <Skeleton className="h-4 w-20 mb-2" />
        <Skeleton className="h-5 w-full mb-1" />
        <Skeleton className="h-4 w-3/4 mb-2" />
        <Skeleton className="h-3 w-16 mb-3" />
        <Skeleton className="h-6 w-20" />
      </CardContent>
      <CardFooter className="p-3 md:p-4 pt-0">
        <Skeleton className="h-10 w-full" />
      </CardFooter>
    </Card>
  );
}
