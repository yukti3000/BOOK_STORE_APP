import { Link } from 'react-router';
import { BookOpen, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-12">
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <BookOpen className="size-6 text-primary" />
              <span className="text-xl font-semibold text-white">BookStore</span>
            </Link>
            <p className="text-sm text-gray-400">
              Your one-stop destination for all your reading needs. Discover, explore, and enjoy great books.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="hover:text-primary transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/#categories" className="hover:text-primary transition-colors">Categories</Link>
              </li>
              <li>
                <Link to="/wishlist" className="hover:text-primary transition-colors">Wishlist</Link>
              </li>
              <li>
                <Link to="/cart" className="hover:text-primary transition-colors">Cart</Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-white font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/profile" className="hover:text-primary transition-colors">My Account</Link>
              </li>
              <li>
                <Link to="/profile?tab=orders" className="hover:text-primary transition-colors">Track Order</Link>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">Help & Support</a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">Return Policy</a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Mail className="size-4 mt-0.5 flex-shrink-0" />
                <span>support@bookstore.in</span>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="size-4 mt-0.5 flex-shrink-0" />
                <span>+91 1800-123-4567</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="size-4 mt-0.5 flex-shrink-0" />
                <span>Bangalore, Karnataka, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-6 text-center text-sm">
          <p>&copy; 2024 BookStore. All rights reserved. Made with ❤️ in India</p>
        </div>
      </div>
    </footer>
  );
}
