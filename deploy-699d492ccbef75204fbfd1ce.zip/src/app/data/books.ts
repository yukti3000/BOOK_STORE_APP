export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  genre: string;
  description: string;
  cover: string;
  rating: number;
  reviews: number;
}

export const books: Book[] = [
  {
    id: "1",
    title: "Pride and Prejudice",
    author: "Jane Austen",
    price: 299,
    genre: "Classic",
    description: "A romantic novel of manners that follows the character development of Elizabeth Bennet, who learns about the repercussions of hasty judgments and comes to appreciate the difference between superficial goodness and actual goodness.",
    cover: "https://images.unsplash.com/photo-1763768861268-cb6b54173dbf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzc2ljJTIwbGl0ZXJhdHVyZSUyMGJvb2slMjBjb3ZlcnxlbnwxfHx8fDE3NzE4MTE5ODB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.8,
    reviews: 2547
  },
  {
    id: "2",
    title: "The Mystery of the Blue Train",
    author: "Agatha Christie",
    price: 249,
    genre: "Mystery",
    description: "When the luxurious Blue Train arrives at Nice, a guard attempts to wake Ruth Kettering from her slumbers. But she will never wake again, for a heavy blow has killed her. The prime suspect is Ruth's estranged husband.",
    cover: "https://images.unsplash.com/photo-1760696473709-a7da66ee87a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJ5JTIwbm92ZWwlMjBjb3ZlcnxlbnwxfHx8fDE3NzE3OTI4MTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.5,
    reviews: 1823
  },
  {
    id: "3",
    title: "Dune",
    author: "Frank Herbert",
    price: 399,
    genre: "Science Fiction",
    description: "Set in the distant future amidst a feudal interstellar society, Dune tells the story of young Paul Atreides, whose family accepts control of the desert planet Arrakis, the only source of the 'spice' melange.",
    cover: "https://images.unsplash.com/photo-1554357395-dbdc356ca5da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbmNlJTIwZmljdGlvbiUyMGJvb2t8ZW58MXx8fHwxNzcxNzkzMTMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    reviews: 3241
  },
  {
    id: "4",
    title: "The Notebook",
    author: "Nicholas Sparks",
    price: 299,
    genre: "Romance",
    description: "A beautiful tale of enduring love, set in post-World War II North Carolina. Noah and Allie's passionate summer romance is rekindled when they reunite years later, proving that true love never dies.",
    cover: "https://images.unsplash.com/photo-1711185901354-73cb6b666c32?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbmNlJTIwbm92ZWwlMjBjb3ZlcnxlbnwxfHx8fDE3NzE4MTQzNjh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.6,
    reviews: 2156
  },
  {
    id: "5",
    title: "The Name of the Wind",
    author: "Patrick Rothfuss",
    price: 349,
    genre: "Fantasy",
    description: "A high-action story written with a poet's hand. It tells the tale of Kvothe, a legendary figure who reveals his life's story to a chronicler in a magical world of heroes, demons, and ancient mysteries.",
    cover: "https://images.unsplash.com/photo-1711185892188-13f35959d3ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYm9vayUyMGNvdmVyfGVufDF8fHx8MTc3MTc5OTQ0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    reviews: 2893
  },
  {
    id: "6",
    title: "Atomic Habits",
    author: "James Clear",
    price: 499,
    genre: "Self-Help",
    description: "No matter your goals, Atomic Habits offers a proven framework for improving every day. James Clear reveals practical strategies that will teach you how to form good habits, break bad ones, and master behaviors.",
    cover: "https://images.unsplash.com/photo-1546913760-e23d946dd386?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWxmJTIwaGVscCUyMGJvb2t8ZW58MXx8fHwxNzcxNzQxNjA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.9,
    reviews: 4521
  },
  {
    id: "7",
    title: "Gone Girl",
    author: "Gillian Flynn",
    price: 299,
    genre: "Thriller",
    description: "On their fifth wedding anniversary, Nick's wife Amy disappears. Under mounting pressure, Nick finds himself becoming the focus of an intense media frenzy. Are there things that Nick has kept from the police?",
    cover: "https://images.unsplash.com/photo-1696947833843-9707b58254fa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aHJpbGxlciUyMGJvb2slMjBjb3ZlcnxlbnwxfHx8fDE3NzE4Mjk4NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.4,
    reviews: 3672
  },
  {
    id: "8",
    title: "Steve Jobs",
    author: "Walter Isaacson",
    price: 599,
    genre: "Biography",
    description: "Based on more than forty interviews with Steve Jobs conducted over two years, this is the definitive portrait of the greatest innovator of his generation. Jobs speaks candidly about his career and life.",
    cover: "https://images.unsplash.com/photo-1769963121626-7f1885db412c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaW9ncmFwaHklMjBib29rJTIwY292ZXJ8ZW58MXx8fHwxNzcxNzk0OTU3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    rating: 4.7,
    reviews: 2934
  }
];