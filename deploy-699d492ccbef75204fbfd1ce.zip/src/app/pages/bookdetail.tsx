import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, ShoppingCart, Star, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { books } from '../data/books';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { Button } from '../components/ui/button';

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  const book = books.find(b => b.id === id);

  if (!book) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Book not found</h2>
        <Button onClick={() => navigate('/')}>Return to Home</Button>
      </div>
    );
  }

  const inWishlist = isInWishlist(book.id);

  const handleAddToCart = () => {
    addToCart(book);
    toast.success(`${book.title} added to cart!`);
  };

  const handleToggleWishlist = () => {
    if (inWishlist) {
      removeFromWishlist(book.id);
      toast.success(`${book.title} removed from wishlist`);
    } else {
      addToWishlist(book);
      toast.success(`${book.title} added to wishlist!`);
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 md:py-8">
      <Button
        variant="ghost"
        onClick={() => navigate(-1)}
        className="mb-4 md:mb-6"
      >
        <ArrowLeft className="size-4 mr-2" />
        Back
      </Button>

      <div className="grid md:grid-cols-2 gap-6 md:gap-8">
        {/* Book Cover */}
        <div className="aspect-[2/3] max-w-sm md:max-w-md mx-auto w-full overflow-hidden rounded-lg shadow-lg">
          <img
            src={book.cover}
            alt={book.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Book Details */}
        <div className="space-y-4 md:space-y-6">
          <div>
            <div className="text-xs md:text-sm text-primary font-medium mb-2">{book.genre}</div>
            <h1 className="text-2xl md:text-4xl font-bold mb-2">{book.title}</h1>
            <p className="text-lg md:text-xl text-gray-600 mb-3 md:mb-4">by {book.author}</p>
            
            <div className="flex items-center gap-2 mb-3 md:mb-4">
              <div className="flex items-center gap-1">
                <Star className="size-4 md:size-5 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold text-sm md:text-base">{book.rating}</span>
              </div>
              <span className="text-gray-500 text-sm md:text-base">({book.reviews} reviews)</span>
            </div>

            <div className="text-2xl md:text-3xl font-bold text-primary mb-4 md:mb-6">
              ₹{book.price}
            </div>
          </div>

          <div>
            <h2 className="text-lg md:text-xl font-semibold mb-2 md:mb-3">Description</h2>
            <p className="text-sm md:text-base text-gray-700 leading-relaxed">{book.description}</p>
          </div>

          <div className="flex gap-3 md:gap-4">
            <Button 
              size="lg" 
              className="flex-1"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="size-4 md:size-5 mr-2" />
              Add to Cart
            </Button>
            <Button
              size="lg"
              variant={inWishlist ? 'default' : 'outline'}
              onClick={handleToggleWishlist}
            >
              <Heart className={`size-4 md:size-5 ${inWishlist ? 'fill-white' : ''}`} />
            </Button>
          </div>

          <div className="border-t pt-4 md:pt-6 space-y-2">
            <div className="flex justify-between text-xs md:text-sm">
              <span className="text-gray-600">Format:</span>
              <span className="font-medium">Hardcover</span>
            </div>
            <div className="flex justify-between text-xs md:text-sm">
              <span className="text-gray-600">Publisher:</span>
              <span className="font-medium">BookStore Publishing</span>
            </div>
            <div className="flex justify-between text-xs md:text-sm">
              <span className="text-gray-600">Language:</span>
              <span className="font-medium">English</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}