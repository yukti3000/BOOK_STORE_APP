import { Link } from 'react-router';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Separator } from '../components/ui/separator';

export default function Cart() {
  const { items, removeFromCart, updateQuantity, getTotalPrice, clearCart } = useCart();
  const totalPrice = getTotalPrice();

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto text-center">
          <ShoppingBag className="size-12 md:size-16 mx-auto mb-4 text-gray-400" />
          <h2 className="text-xl md:text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-sm md:text-base text-gray-600 mb-6">Start adding some books to your cart!</p>
          <Link to="/">
            <Button size="lg">Browse Books</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 md:py-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">Shopping Cart</h1>

      <div className="grid lg:grid-cols-3 gap-6 md:gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-3 md:space-y-4">
          {items.map(item => (
            <Card key={item.id}>
              <CardContent className="p-3 md:p-4">
                <div className="flex gap-3 md:gap-4">
                  <img
                    src={item.cover}
                    alt={item.title}
                    className="w-20 h-28 md:w-24 md:h-32 object-cover rounded flex-shrink-0"
                  />
                  
                  <div className="flex-1 min-w-0">
                    <Link to={`/book/${item.id}`}>
                      <h3 className="font-semibold text-sm md:text-base hover:text-primary transition-colors mb-1 line-clamp-2">
                        {item.title}
                      </h3>
                    </Link>
                    <p className="text-xs md:text-sm text-gray-600 mb-1 md:mb-2 line-clamp-1">{item.author}</p>
                    <p className="text-xs text-gray-500 mb-2 md:mb-3">{item.genre}</p>
                    <p className="font-bold text-sm md:text-base text-primary">₹{item.price}</p>
                  </div>

                  <div className="flex flex-col justify-between items-end flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 className="size-3 md:size-4 text-destructive" />
                    </Button>

                    <div className="flex items-center gap-1 md:gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7 md:h-8 md:w-8"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="size-3" />
                      </Button>
                      <span className="w-6 md:w-8 text-center text-sm font-medium">{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7 md:h-8 md:w-8"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus className="size-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          <Button
            variant="outline"
            onClick={clearCart}
            className="w-full text-sm"
          >
            Clear Cart
          </Button>
        </div>

        {/* Order Summary */}
        <div>
          <Card className="sticky top-20">
            <CardContent className="p-4 md:p-6">
              <h2 className="text-lg md:text-xl font-bold mb-3 md:mb-4">Order Summary</h2>
              
              <div className="space-y-2 md:space-y-3 mb-3 md:mb-4">
                {items.map(item => (
                  <div key={item.id} className="flex justify-between text-xs md:text-sm">
                    <span className="text-gray-600 line-clamp-1 flex-1 pr-2">
                      {item.title} x {item.quantity}
                    </span>
                    <span className="font-medium flex-shrink-0">
                      ₹{(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>

              <Separator className="my-3 md:my-4" />

              <div className="space-y-2 mb-4 md:mb-6">
                <div className="flex justify-between text-xs md:text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">₹{totalPrice}</span>
                </div>
                <div className="flex justify-between text-xs md:text-sm">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium text-green-600">Free</span>
                </div>
              </div>

              <Separator className="my-3 md:my-4" />

              <div className="flex justify-between text-base md:text-lg font-bold mb-4 md:mb-6">
                <span>Total</span>
                <span className="text-primary">₹{totalPrice}</span>
              </div>

              <Button className="w-full mb-2" size="lg" asChild>
                <Link to="/checkout">
                  Proceed to Checkout
                </Link>
              </Button>

              <Link to="/">
                <Button variant="ghost" className="w-full text-sm">
                  Continue Shopping
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}