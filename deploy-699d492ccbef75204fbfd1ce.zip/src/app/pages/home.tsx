import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router';
import { BookOpen, TrendingUp, Sparkles } from 'lucide-react';
import { books } from '../data/books';
import { BookCard } from '../components/BookCard';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';

const genres = ['All', 'Classic', 'Mystery', 'Science Fiction', 'Romance', 'Fantasy', 'Self-Help', 'Thriller', 'Biography'];

const categoryIcons: Record<string, any> = {
  'Classic': '📚',
  'Mystery': '🔍',
  'Science Fiction': '🚀',
  'Romance': '💕',
  'Fantasy': '🐉',
  'Self-Help': '🌟',
  'Thriller': '⚡',
  'Biography': '👤'
};

export default function Home() {
  const [searchParams] = useSearchParams();
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const query = searchParams.get('search');
    if (query) {
      setSearchQuery(query);
    }
  }, [searchParams]);

  const filteredBooks = books.filter(book => {
    const matchesGenre = selectedGenre === 'All' || book.genre === selectedGenre;
    const matchesSearch = searchQuery === '' || 
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGenre && matchesSearch;
  });

  // Featured books (highest rated)
  const featuredBooks = [...books].sort((a, b) => b.rating - a.rating).slice(0, 3);

  // Trending books (most reviews)
  const trendingBooks = [...books].sort((a, b) => b.reviews - a.reviews).slice(0, 4);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-5xl font-bold mb-3 md:mb-4">
              Discover Your Next Great Read
            </h1>
            <p className="text-base md:text-lg text-gray-600 mb-6">
              Browse our curated collection of books across all genres. From classics to contemporary bestsellers.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" asChild>
                <Link to="#categories">
                  <BookOpen className="size-5 mr-2" />
                  Browse Categories
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="#trending">
                  <TrendingUp className="size-5 mr-2" />
                  View Trending
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Books */}
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 mb-6">
            <Sparkles className="size-6 text-primary" />
            <h2 className="text-2xl md:text-3xl font-bold">Featured Books</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredBooks.map(book => (
              <Card key={book.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <Link to={`/book/${book.id}`}>
                  <div className="aspect-[16/9] overflow-hidden bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center p-6">
                    <img
                      src={book.cover}
                      alt={book.title}
                      className="h-full w-auto object-contain shadow-2xl"
                    />
                  </div>
                  <CardContent className="p-4">
                    <p className="text-xs text-primary font-medium mb-1">{book.genre}</p>
                    <h3 className="font-bold text-lg mb-1 line-clamp-1">{book.title}</h3>
                    <p className="text-sm text-gray-600 mb-2">{book.author}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-primary">₹{book.price}</span>
                      <span className="text-sm text-gray-600">⭐ {book.rating}</span>
                    </div>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section id="categories" className="py-8 md:py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-6">Browse by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {genres.filter(g => g !== 'All').map(genre => (
              <Card
                key={genre}
                className="cursor-pointer hover:shadow-lg transition-all hover:scale-105"
                onClick={() => {
                  setSelectedGenre(genre);
                  document.getElementById('all-books')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                <CardContent className="p-4 md:p-6 text-center">
                  <div className="text-4xl mb-3">{categoryIcons[genre]}</div>
                  <h3 className="font-semibold text-sm md:text-base">{genre}</h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {books.filter(b => b.genre === genre).length} books
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Books */}
      <section id="trending" className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="size-6 text-primary" />
            <h2 className="text-2xl md:text-3xl font-bold">Trending Now</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {trendingBooks.map(book => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>

      {/* All Books */}
      <section id="all-books" className="py-8 md:py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-6">All Books</h2>
          
          {/* Genre Filter */}
          <div className="mb-6 md:mb-8 flex flex-wrap gap-2">
            {genres.map(genre => (
              <Button
                key={genre}
                variant={selectedGenre === genre ? 'default' : 'outline'}
                onClick={() => setSelectedGenre(genre)}
                size="sm"
              >
                {genre}
              </Button>
            ))}
          </div>

          {/* Books Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filteredBooks.map(book => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>

          {filteredBooks.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No books found matching your criteria.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => {
                  setSelectedGenre('All');
                  setSearchQuery('');
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
