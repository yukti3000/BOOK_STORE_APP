import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router';
import { User, Package, Heart, Settings, BookOpen, Mail, Phone } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';

// Mock order data
const mockOrders = [
  {
    id: 'ORD-2024-001',
    date: '2024-02-15',
    status: 'Delivered',
    total: 1197,
    items: [
      { title: 'Atomic Habits', quantity: 1, price: 499 },
      { title: 'Dune', quantity: 1, price: 399 },
      { title: 'Pride and Prejudice', quantity: 1, price: 299 },
    ],
  },
  {
    id: 'ORD-2024-002',
    date: '2024-02-20',
    status: 'In Transit',
    total: 648,
    items: [
      { title: 'The Name of the Wind', quantity: 1, price: 349 },
      { title: 'Gone Girl', quantity: 1, price: 299 },
    ],
  },
];

export default function Profile() {
  const [searchParams] = useSearchParams();
  const { wishlist } = useWishlist();
  const [activeTab, setActiveTab] = useState('profile');
  const [profileData, setProfileData] = useState({
    name: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    phone: '+91 98765 43210',
    address: '123, MG Road, Bangalore, Karnataka - 560001',
  });

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, [searchParams]);

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate profile update
    alert('Profile updated successfully!');
  };

  return (
    <div className="container mx-auto px-4 py-6 md:py-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">My Account</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
          <TabsTrigger value="profile" className="text-xs md:text-sm">
            <User className="size-4 mr-2 hidden md:inline" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="orders" className="text-xs md:text-sm">
            <Package className="size-4 mr-2 hidden md:inline" />
            Orders
          </TabsTrigger>
          <TabsTrigger value="wishlist" className="text-xs md:text-sm">
            <Heart className="size-4 mr-2 hidden md:inline" />
            Wishlist
          </TabsTrigger>
          <TabsTrigger value="settings" className="text-xs md:text-sm">
            <Settings className="size-4 mr-2 hidden md:inline" />
            Settings
          </TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProfileUpdate} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={profileData.phone}
                      onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={profileData.address}
                      onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                    />
                  </div>
                  <Button type="submit" className="w-full">Update Profile</Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Account Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-primary/5 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Package className="size-8 text-primary" />
                    <div>
                      <p className="text-2xl font-bold">{mockOrders.length}</p>
                      <p className="text-sm text-gray-600">Total Orders</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Heart className="size-8 text-red-500" />
                    <div>
                      <p className="text-2xl font-bold">{wishlist.length}</p>
                      <p className="text-sm text-gray-600">Wishlist Items</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <BookOpen className="size-8 text-blue-500" />
                    <div>
                      <p className="text-2xl font-bold">
                        {mockOrders.reduce((acc, order) => acc + order.items.reduce((sum, item) => sum + item.quantity, 0), 0)}
                      </p>
                      <p className="text-sm text-gray-600">Books Purchased</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Orders Tab */}
        <TabsContent value="orders">
          <div className="space-y-4">
            {mockOrders.map(order => (
              <Card key={order.id}>
                <CardContent className="p-4 md:p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-1">Order #{order.id}</h3>
                      <p className="text-sm text-gray-600">
                        Placed on {new Date(order.date).toLocaleDateString('en-IN', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    <div className="mt-2 md:mt-0">
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                        order.status === 'Delivered' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="text-gray-600">
                          {item.title} x {item.quantity}
                        </span>
                        <span className="font-medium">₹{item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <span className="font-bold">Total Amount</span>
                    <span className="text-lg font-bold text-primary">₹{order.total}</span>
                  </div>
                </CardContent>
              </Card>
            ))}

            {mockOrders.length === 0 && (
              <Card>
                <CardContent className="p-12 text-center">
                  <Package className="size-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">No orders yet</h3>
                  <p className="text-gray-600 mb-4">Start shopping to see your orders here!</p>
                  <Link to="/">
                    <Button>Browse Books</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Wishlist Tab */}
        <TabsContent value="wishlist">
          <Card>
            <CardContent className="p-6">
              {wishlist.length > 0 ? (
                <div className="space-y-4">
                  {wishlist.map(book => (
                    <div key={book.id} className="flex gap-4 p-4 border rounded-lg">
                      <Link to={`/book/${book.id}`}>
                        <img
                          src={book.cover}
                          alt={book.title}
                          className="w-16 h-24 object-cover rounded"
                        />
                      </Link>
                      <div className="flex-1">
                        <Link to={`/book/${book.id}`}>
                          <h3 className="font-semibold hover:text-primary transition-colors mb-1">
                            {book.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-gray-600 mb-2">{book.author}</p>
                        <p className="text-lg font-bold text-primary">₹{book.price}</p>
                      </div>
                      <Link to={`/book/${book.id}`}>
                        <Button size="sm">View Details</Button>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Heart className="size-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">Your wishlist is empty</h3>
                  <p className="text-gray-600 mb-4">Add books you love to your wishlist!</p>
                  <Link to="/">
                    <Button>Browse Books</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Mail className="size-5 text-gray-600" />
                    <div>
                      <p className="font-medium">Email Notifications</p>
                      <p className="text-xs text-gray-500">Receive order updates via email</p>
                    </div>
                  </div>
                  <input type="checkbox" defaultChecked className="toggle" />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Phone className="size-5 text-gray-600" />
                    <div>
                      <p className="font-medium">SMS Notifications</p>
                      <p className="text-xs text-gray-500">Get delivery updates via SMS</p>
                    </div>
                  </div>
                  <input type="checkbox" defaultChecked className="toggle" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Account Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  Change Password
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Privacy Settings
                </Button>
                <Button variant="outline" className="w-full justify-start text-destructive hover:text-destructive">
                  Delete Account
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
