import { Link } from 'react-router';
import { Heart, ShoppingCart, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';

export default function Wishlist() {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();

  const handleAddToCart = (book: any) => {
    addToCart(book);
    toast.success(`${book.title} added to cart!`);
  };

  if (wishlist.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto text-center">
          <Heart className="size-12 md:size-16 mx-auto mb-4 text-gray-400" />
          <h2 className="text-xl md:text-2xl font-bold mb-2">Your wishlist is empty</h2>
          <p className="text-sm md:text-base text-gray-600 mb-6">
            Start adding books you'd love to read!
          </p>
          <Link to="/">
            <Button size="lg">Browse Books</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 md:py-8">
      <div className="flex items-center justify-between mb-6 md:mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-1">My Wishlist</h1>
          <p className="text-sm md:text-base text-gray-600">
            {wishlist.length} {wishlist.length === 1 ? 'book' : 'books'} saved
          </p>
        </div>
        <Button variant="outline" onClick={clearWishlist} className="text-sm">
          Clear All
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {wishlist.map(book => (
          <Card key={book.id} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex gap-4">
                <Link to={`/book/${book.id}`} className="flex-shrink-0">
                  <img
                    src={book.cover}
                    alt={book.title}
                    className="w-20 h-28 md:w-24 md:h-32 object-cover rounded shadow-md hover:scale-105 transition-transform"
                  />
                </Link>
                
                <div className="flex-1 min-w-0">
                  <Link to={`/book/${book.id}`}>
                    <h3 className="font-semibold text-sm md:text-base mb-1 hover:text-primary transition-colors line-clamp-2">
                      {book.title}
                    </h3>
                  </Link>
                  <p className="text-xs md:text-sm text-gray-600 mb-2 line-clamp-1">
                    {book.author}
                  </p>
                  <p className="text-xs text-gray-500 mb-2">{book.genre}</p>
                  <p className="text-base md:text-lg font-bold text-primary mb-3">
                    ₹{book.price}
                  </p>
                  
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1 text-xs"
                      onClick={() => handleAddToCart(book)}
                    >
                      <ShoppingCart className="size-3 mr-1" />
                      Add to Cart
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        removeFromWishlist(book.id);
                        toast.success('Removed from wishlist');
                      }}
                    >
                      <Trash2 className="size-3 text-destructive" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
